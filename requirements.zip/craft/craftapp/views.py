from django.shortcuts import render, redirect,HttpResponseRedirect
from django.contrib.auth.hashers import check_password, make_password
from .middlewares.auth import auth_middleware
from django.http import HttpResponse
from .models import Products
from .models import Category
from .models import Customer
from .models import Order
from django.views import View


# Create your views here.
def home(request):
    cart = request.session.get('cart')
    if not cart:
        request.session['cart'] = {}
    products = None
    categories = Category.get_all_categories()
    categoryID = request.GET.get('category')
    if categoryID:
        products = Products.get_all_products_by_categoryid(categoryID)
    else:
        products = Products.get_all_products()
    data = {}
    data['products'] = products
    data['categories'] = categories
    print('You are : ', request.session.get('email'))
    return render(request, 'index.html',data)


def validateCustomer(customer):
    error_message = None
    if (not customer.first_name):
        error_message = "First Name Required"
    elif len(customer.first_name) < 4:
        error_message = "first name must be 4 char long or more"
    elif (not customer.last_name):
        error_message = "Last Name Required"
    elif len(customer.last_name) < 4:
        error_message = "last name must be 4 char long or more"
    elif not customer.phone:
        error_message = "Phone number Required"
    elif len(customer.phone) < 10:
        error_message = "Phone no must be 10 digit long or more"
    elif (not customer.password):
        error_message = "Password Required"
    elif len(customer.password) < 8:
        error_message = "Password must be 8 char long or more"
    elif (not customer.email):
        error_message = "E-mail Required"
    elif len(customer.email) < 6:
        error_message = "E-mail must be 6 char long or more"
    elif customer.isExists():
        error_message = 'Email already registered..!'
    # saving
    return error_message


def registerUser(request):
    postData = request.POST
    first_name = postData.get('fname')
    last_name = postData.get('lname')
    phone = postData.get('phno')
    password = postData.get('pass')
    email = postData.get('email')
    # validation
    value = {
        'first_name': first_name,
        'last_name': last_name,
        'phone': phone,
        'email': email,
    }

    error_message = None

    customer = Customer(first_name=first_name, last_name=last_name, phone=phone, email=email, password=password)
    error_message = validateCustomer(customer)
    if not error_message:
        print(first_name, last_name, phone, password, email)

        customer.register()
        return redirect('home')
    else:
        data = {
            'error': error_message,
            'values': value
        }
        return render(request, 'signup.html', data)


def signup(request):
    if request.method == 'GET':
        return render(request, 'signup.html')
    else:
        return registerUser(request)


def login(request):
    return_url = None

    if request.method == 'GET':
        login.return_url = request.GET.get('return_url')
        return render(request, 'login.html')
    else:
        email = request.POST.get('email')
        password = request.POST.get('pass')
        customer = Customer.get_customer_by_email(email)
        error_message = None
        if customer:
            flag = check_password(password, customer.password)
            if flag:

                return redirect('home')

            else:
                request.session['customer'] = customer.id
                if login.return_url:
                    return HttpResponseRedirect(login.return_url)
                else:
                    login.return_url = None
                    return redirect('home')
        else:
            print(email, password)
            return render(request, 'signup.html', {'error': error_message})


def cart(request):
    product = request.POST.get('product')
    remove = request.POST.get('remove')
    cart = request.session.get('cart')
    if cart:
        quantity = cart.get(product)
        if quantity:
            if remove:
                if quantity == 1:
                    cart.pop(product)
                else:
                    cart[product] = quantity - 1
            else:
                cart[product] = quantity + 1
        else:
            cart[product] = 1
    else:
        cart = {}
        cart[product] = 1
    request.session['cart'] = cart
    print('cart', request.session['cart'])
    return redirect('home')


def logout(request):
    request.session.clear()
    return redirect('login')


def carts(request):
    ids = list(request.session.get('cart').keys())
    products = Products.get_products_by_id(ids)
    print(products)
    return render(request, 'cart.html', {'products': products})

def checkout(request):
    address = request.POST.get('address')
    phone = request.POST.get('phone')
    customer = request.session.get('customer')
    cart = request.session.get('cart')
    products = Products.get_products_by_id(list(cart.keys()))
    print(customer,phone,address,cart,products)

    for product in products:
        print(cart.get(str(product.id)))
        order = Order(customer=Customer(id=customer),
                      product=product,
                      price=product.price,
                      address=address,
                      phone=phone,
                      quantity=cart.get(str(product.id)))
        order.save()
    request.session['cart'] = {}
    return redirect('carts')

@auth_middleware
def orders(request):

    customer = request.session.get('customer')
    orders = Order.get_orders_by_customer(customer)
    print(orders)
    orders = orders.reverse()
    return render(request,'orders.html', {'orders':orders})